# Milestone 2E — Database DDL & Migration Baseline Report

**Date:** 31 October 2026  
**Package:** CIT Backend Database Package v0.3

## Delivered artifacts

- PostgreSQL DDL baseline: `sql/0001_initial_schema.sql`
- Alembic revision: `migrations/versions/0001_initial.py`
- Alembic environment and configuration.
- SQLAlchemy 2.x model mapping plan.
- Migration/import runbook.
- Schema acceptance SQL checks.
- Starter environment and dependency files.

## Baseline inventory

- PostgreSQL schemas: 12
- Tables: 78
- Explicit indexes: 12
- Alembic revision: `0001_initial`

### PostgreSQL schemas

core, academic, identity, scheduling, booking, exams, change_mgmt, approvals, analytics, assistant, notifications, integration

### Table inventory

- `core.institutes`
- `core.departments`
- `core.source_artifacts`
- `core.dataset_versions`
- `core.dataset_policy`
- `core.dataset_activations`
- `core.calendar_versions`
- `core.calendar_days`
- `core.calendar_periods`
- `core.calendar_breaks`
- `core.calendar_lab_start_periods`
- `core.calendar_event_periods`
- `core.calendar_exam_days`
- `core.calendar_exam_sessions`
- `identity.users`
- `identity.user_role_assignments`
- `identity.auth_sessions`
- `core.audit_events`
- `academic.rooms`
- `academic.room_features`
- `academic.room_feature_assignments`
- `academic.room_allowed_uses`
- `academic.faculty`
- `academic.student_groups`
- `academic.courses`
- `academic.teaching_sessions`
- `academic.session_groups`
- `academic.session_allowed_room_types`
- `academic.faculty_unavailability`
- `academic.room_unavailability`
- `academic.faculty_preferences`
- `scheduling.timetable_versions`
- `scheduling.timetable_generation_requests`
- `scheduling.solver_runs`
- `scheduling.timetable_assignments`
- `scheduling.timetable_occupancy`
- `scheduling.solver_metrics`
- `scheduling.validation_runs`
- `scheduling.validation_violations`
- `scheduling.timetable_publications`
- `scheduling.published_timetable_pointers`
- `booking.booking_requests`
- `booking.booking_cancellations`
- `booking.booking_windows`
- `booking.booking_allowed_room_types`
- `booking.booking_required_features`
- `booking.booking_mandatory_groups`
- `booking.booking_decisions`
- `booking.booking_allocations`
- `booking.booking_alternative_responses`
- `booking.fest_week_versions`
- `booking.fest_week_booking_decisions`
- `booking.session_overrides`
- `booking.booking_priority_evaluations`
- `approvals.approval_tasks`
- `approvals.approval_events`
- `exams.exam_records`
- `exams.exam_courses`
- `exams.exam_groups`
- `exams.exam_schedule_versions`
- `exams.exam_assignments`
- `exams.exam_room_allocations`
- `change_mgmt.disruption_sets`
- `change_mgmt.disruption_changes`
- `change_mgmt.change_proposals`
- `change_mgmt.change_proposal_items`
- `change_mgmt.change_approvals`
- `change_mgmt.applied_change_sets`
- `analytics.metric_snapshots`
- `assistant.conversations`
- `assistant.messages`
- `assistant.tool_executions`
- `notifications.notifications`
- `integration.import_jobs`
- `integration.export_jobs`
- `integration.validator_runs`
- `integration.background_jobs`
- `integration.idempotency_records`

## Verification performed

1. Alembic offline SQL rendering completed successfully using `alembic upgrade head --sql`.
2. The migration revision was loaded by Alembic and rendered into a static PostgreSQL migration script.
3. The DDL and migration source files were packaged with their runbook and acceptance checks.

## Verification not yet performed

**No live PostgreSQL server was available in this execution environment.** Therefore:
- The DDL has not been executed against a real PostgreSQL instance.
- Foreign-key and index creation have not been verified by PostgreSQL itself.
- Import transactions have not been run.
- No starter dataset has been inserted.
- No business workflow is implemented by this schema package alone.

Do not describe this baseline as production-tested or deployed. The next validation step is to apply it to a disposable PostgreSQL database and run `tests/schema_acceptance.sql`.

## Important review items before production use

1. Complete composite same-dataset foreign keys for every imported child relationship, not only the principal session/course/faculty/calendar links.
2. Add database-level immutability protections or restrict update permissions for imported and published version rows.
3. Confirm the application role and scope model; no fifth competition role has been introduced.
4. Confirm alternative-response export semantics and reviewer routing.
5. Add the final official export schema and golden fixtures before declaring integration-ready.
6. Confirm the exact Postgres major version and hosting environment.

## Honest status

**Milestone 2E baseline artifacts created; live database validation remains pending.** This is the correct point to review and run the first disposable database migration—not to begin frontend work.
