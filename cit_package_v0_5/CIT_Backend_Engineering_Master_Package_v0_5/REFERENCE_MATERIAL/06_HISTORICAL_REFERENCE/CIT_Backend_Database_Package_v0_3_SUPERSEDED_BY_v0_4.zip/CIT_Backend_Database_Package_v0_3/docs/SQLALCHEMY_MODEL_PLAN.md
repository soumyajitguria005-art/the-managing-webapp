# SQLAlchemy 2.x Model Plan — CIT v0.3

## Mapping conventions
- Use `DeclarativeBase` and typed `Mapped[...]` declarations.
- UUID primary keys map to PostgreSQL UUID and `uuid.uuid4` only where DB default is not used.
- `JSONB` for source snapshots, policy snapshots, flexible change payloads and validator evidence.
- `DateTime(timezone=True)` for instants; `Time` for recurring period boundaries.
- Use `Numeric` for hour values; do not use floating point for hours/weights.
- Keep `external_id` distinct from internal UUID.
- Model composite uniqueness and FK constraints in `__table_args__`.
- Avoid ORM cascade-delete for immutable source/decision history.
- Keep SQLAlchemy relationships one-directional where bidirectional cascade behaviour risks accidental deletes.

## Model modules
| Python module | Tables |
|---|---|
| `app/modules/datasets/models.py` | `core.dataset_versions`, `dataset_policy`, `dataset_activations`, `source_artifacts` |
| `app/modules/academic/models.py` | rooms, room features/uses, faculty, groups, courses, sessions, relationships, unavailability, preferences |
| `app/modules/scheduling/models.py` | timetable versions, generation requests, solver runs, assignments, occupancy, metrics, validations, publications |
| `app/modules/booking/models.py` | requests, cancellations, windows, requirements, decisions, allocations, alternative responses, fest-week versions, overrides, priority evaluations |
| `app/modules/exams/models.py` | exam records, courses, groups, schedule versions, assignments, room allocations |
| `app/modules/change_management/models.py` | disruption sets/changes, proposals/items/approvals, applied change sets |
| `app/modules/identity/models.py` | users, role assignments, auth sessions |
| `app/modules/approvals/models.py` | approval tasks/events |
| `app/modules/integration/models.py` | import/export jobs, validator runs, background jobs, idempotency records |
| `app/modules/assistant/models.py` | conversations, messages, tool executions |
| `app/modules/notifications/models.py` | notifications |
| `app/modules/audit/models.py` | audit events |

## Important mapping details
1. `teaching_sessions` references `courses` and `faculty` with composite `(id, dataset_version_id)` integrity. Mirror this in ORM `ForeignKeyConstraint`.
2. `timetable_versions` references `(calendar_version_id, dataset_version_id)` as a composite FK.
3. `timetable_occupancy` is a derived projection. Rebuild it from assignments in the same transaction after draft edits.
4. `booking_decisions.is_effective` has a partial unique index by `booking_request_id`; define with PostgreSQL `Index(..., postgresql_where=text("is_effective"))`.
5. `session_overrides` has unique `(fest_week_version_id, session_id)`.
6. Do not add `delete-orphan` cascades to imported academic entities, decisions, audit events or published versions.
7. Domain services own lifecycle transitions; ORM models do not silently mutate state on property setters.
8. Keep Alembic migrations authoritative. Do not use `Base.metadata.create_all()` in production.

## First implementation order
1. Core + identity models.
2. Academic models.
3. Import repositories and source mapping.
4. Scheduling models.
5. Booking models.
6. Exam and change-management models.
7. Approval, audit, analytics, assistant, notification and integration models.

This is a mapping plan, not a claim that all ORM classes have already been authored.
