# CIT Database Migration & Import Runbook v0.3

## Prerequisites
- PostgreSQL 15+ recommended.
- Python 3.11+.
- `pip install "SQLAlchemy>=2.0,<2.1" "alembic>=1.13" "psycopg[binary]>=3.1"`.
- Create an empty database and a dedicated least-privilege application role.
- Set `DATABASE_URL` as an environment variable. Never commit real credentials.

## Apply baseline
```bash
alembic upgrade head
```
The baseline creates the PostgreSQL namespaces and initial tables. Review the SQL in `sql/0001_initial_schema.sql` before applying it to any non-disposable database.

## Inspect migration state
```bash
alembic current
alembic history
```

## Generate later migrations
```bash
alembic revision -m "add domain capability"
```
Review generated migrations manually. Autogenerate is a diff assistant, not an authority. Do not edit old applied migrations.

## Import transaction design
1. Upload source file to private artifact storage; calculate SHA-256.
2. Parse the JSON with strict Pydantic models before DB writes.
3. Validate root keys, nested shapes, IDs, references, calendar references, and enum values.
4. Begin transaction; create dataset version in `IMPORTING`.
5. Insert institute/calendar/policy/master data and normalized child relations.
6. Compare imported counts and ID sets against the source payload.
7. Store import report and mark `IMPORTED`.
8. Commit.
9. Activation is a separate transaction: lock institute's active dataset pointer, deactivate prior active record, activate exact version, append audit event.
10. On any import failure, rollback all new dataset rows; record a failed import job/report separately.

## Re-import/idempotency
- Same source checksum may be recognized as a duplicate import; do not silently overwrite.
- A deliberate re-import creates a new `dataset_versions` row/version.
- Same `Idempotency-Key` + same request hash returns the original result.
- Same key + different request hash returns HTTP 409.

## Downgrade
The initial migration downgrade drops all CIT schemas and is destructive. Use only on an empty/disposable database. For production, prefer forward-only corrective migrations and backups.

## Important implementation note
The SQL baseline is a reviewable starting point, not proof that all workflows are implemented. Run migrations on a real PostgreSQL instance and execute the acceptance suite before calling the database ready.
