# CIT Backend Database Package v0.3

This package is the Milestone 2E database baseline deliverable.

## Contents
- `sql/0001_initial_schema.sql` — PostgreSQL baseline DDL.
- `migrations/versions/0001_initial.py` — Alembic baseline migration.
- `migrations/env.py`, `alembic.ini` — migration configuration.
- `docs/SQLALCHEMY_MODEL_PLAN.md` — ORM mapping plan.
- `docs/MIGRATION_IMPORT_RUNBOOK.md` — migration and source import procedure.
- `tests/schema_acceptance.sql` — post-migration metadata checks.

## Scope
Backend/database first. Frontend intentionally deferred. Campus Navigator intentionally held; no map-processing or routing tables are created in this baseline.

## Important status
This is a proposed initial schema/migration baseline, not a deployed or PostgreSQL-executed database. Before using it for real data:
1. Review the DDL and open policy decisions.
2. Apply to a disposable PostgreSQL database.
3. Fix any dialect/runtime issues found.
4. Run schema acceptance checks.
5. Only then import the starter dataset.

## Known design follow-ups
- Add the exact competition export adapter and compare with golden fixtures.
- Add composite same-dataset FKs to every child relationship table in a hardening migration.
- Decide whether the application uses local passwords or an external OIDC provider.
- Confirm reviewer routing and alternative-response export semantics.
- Confirm team Python/FastAPI capability.
